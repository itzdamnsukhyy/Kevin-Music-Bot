# Telethon-Music

# String Session (Telethon)

<p align="center"><a href="https://replit.com/@Itz-zaid/Generator"> <img src="https://img.shields.io/badge/String%20Session-black?style=for-the-badge&logo=web" width="220" height="38.45"/></a></p>

# Free Tutorials/Hosting Methods 

<p align="center">Releasehub </p>

<p align="center"><a href="https://youtu.be/IDDyldUHOKo"> <img src="https://img.shields.io/badge/Releasehub%20Deploy-black?style=for-the-badge&logo=youtube" width="220" height="38.45"/></a></p>

<p align="center">Railway </p>

<p align="center"><a href="https://youtu.be/Uzof6djzD-M"> <img src="https://img.shields.io/badge/Railway%20Deploy-black?style=for-the-badge&logo=railway" width="220" height="38.45"/></a></p> 

<p align="center">Scalingo </p>

<p align="center"><a href="https://youtu.be/NjKUeaAM0RI"> <img src="https://img.shields.io/badge/Scalingo%20Deploy-blue?style=for-the-badge&logo=youtube" width="220" height="38.45"/></a></p>

<p align="center">Doprax </p>

<p align="center"><a href="https://youtu.be/NjKUeaAM0RI"> <img src="https://img.shields.io/badge/Doprax%20Deploy-blue?style=for-the-badge&logo=youtube" width="220" height="38.45"/></a></p>


## Local Deployment Process
```sh
sudo apt update && apt upgrade -y
sudo apt install git curl python3-pip ffmpeg -y
pip3 install -U pip
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.38.0/install.sh | bash 
source ~/.bashrc
nvm install v18 #nodejs 18+
git clone https://github.com/ITZ-ZAID/Telethon-Music # clone the repo.
cd Telethon-Music
pip3 install -U -r requirements.txt
nano config.py #edit your vars separate by space
#control+x then y to exit
python3 -m Zaid # run the bot.
```
#

<p align="center">𝐒𝐮𝐩𝐩𝐨𝐫𝐭 / 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 ----> </p>

<p align="center"><a href="https://t.me/TheSupportChat"><img src="https://img.shields.io/badge/ᴛᴇʟᴇɢʀᴀᴍ-𝐒𝐮𝐩𝐩𝐨𝐫𝐭-black?&style=for-the-badge&logo=telegram" width="220" height="38.45"></a></p>
<p align="center"><a href="https://t.me/TheUpdatesChannel"><img src="https://img.shields.io/badge/ᴛᴇʟᴇɢʀᴀᴍ-𝐔𝐩𝐝𝐚𝐭𝐞𝐬-black?&style=for-the-badge&logo=telegram" width="220" height="38.45"></a></p>

# Credits
- Man Userbot
- telethon library
- pytgcalls
